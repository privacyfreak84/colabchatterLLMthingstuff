# PDF reconnaissance: Buddhist Yoga: A Comprehensive Course

- Pages: **122**
- Extracted words: **29,437**
- Characters: **189,046**
- SHA-256: `ea12301ce6e844c01395e9b09bca987a8b22f070e0efd75dadd87ed45acd92f2`
- Text-empty pages: None

## Bookmarks / outline

- p. 2: Translator's Preface
- p. 7: Chapter 1. Introduction
- p. 10: Chapter 2. Characteristics of Ultimate Truth
- p. 25: Chapter 3. Characteristics of Mind, Intellect, and Consciousness
- p. 28: Chapter 4. Characteristics of All Phenomena
- p. 31: Chapter 5. Essencelessness
- p. 47: Chapter 6. Analyzing Yoga
- p. 77: Chapter 7. The Transcendent Ways of the Stages
- p. 100: Chapter 8. Deeds of the Enlightened
- p. 116: Notes
  - p. 116: Footnote to the Translator's Preface
  - p. 116: Notes on Chapter 2: Characteristics of Ultimate Truth
  - p. 117: Notes on Chapter 4: Characteristics of All Phenomena
  - p. 118: Notes on Chapter 6: Analyzing Yoga
  - p. 119: Notes on Chapter 7: The Transcendent Ways of the Stages

## Findings

- **low_text_page**: Page has unusually little extractable text; verify whether it is a title/transition page or extraction issue. Sample: `PDF page 1: 9 words`
- **low_text_page**: Page has unusually little extractable text; verify whether it is a title/transition page or extraction issue. Sample: `PDF page 76: 6 words`

## Chapter coverage

- Expected: [1, 2, 3, 4, 5, 6, 7, 8]
- Found: [1, 2, 3, 4, 5, 6, 7, 8]
- Missing: []
- Complete: **True**
